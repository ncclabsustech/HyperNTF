function [Us, nIter_final, infoo, ela] = HyperNTF(X, Xsize, J, options)
K = options.K;
maxIter = options.maxIter;
nRepeat = options.nRepeat;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nmodes = length(Xsize);
ela = cputime;
alpha = options.alpha;
% ==================================== Construct Graph ====================
%[ D, W ] = hypergraph(X,K);
[ D, W ] = hypergraphL(X,K);
% =========================================================================    
T = reshape(X, Xsize);
T = tensor(T);
Us = cell(nmodes, 1);
% =========================================================================
for kmode = 1:nmodes-1
    
    Us{kmode} = rand(Xsize(kmode),J);
    Us{kmode} = Us{kmode}.*repmat(1./sum(Us{kmode}),Xsize(kmode),1);
end
Us{end} = rand(Xsize(end),J);

    tryNo = 0;
while tryNo < nRepeat   
    tryNo = tryNo+1;
    nIter = 0;
    
    while(nIter < maxIter+1)
        % ===================== update U1,...,Un-1 ========================
        for n = 1:nmodes-1
            A = mttkrp(T, Us, n);
            B = etth(Us, n, J);
            UB = Us{n}*B; % nk^2
            Us{n} = Us{n}.*(A./max(UB, 1e-10)); 
            Us{n} = Us{n}.*repmat(1./sum(Us{n}),Xsize(n),1);
        end
        
        % ===================== update UN =================================
        XK = mttkrp(T, Us, nmodes);
        KW = W*Us{end};
        KD = D*Us{end};
        XK = XK + alpha*KW;
        BB = etth(Us, nmodes, J);
        K2UU = Us{end}*BB; % nk^2
        K2UU = K2UU + alpha*KD;
        Us{end} = Us{end}.*(XK./max(K2UU, 1e-10));
        %Us{end} = Us{end}.*repmat(1./sum(Us{end}),Xsize(end),1);
        
        
        nIter = nIter + 1;
        obj = CalculateObj(T, Us, J);
        nIter_final = (tryNo-1)*maxIter + nIter;
        infoo.rse(nIter_final) = obj;
        disp(['HyerNTF algorithm in the iteration error: ',num2str(obj)]);
    end
 
end
%[Us] = NormalizeU(Us, nmodes);
ela=cputime-ela;




function [ U ] = NormalizeU(U, k)
    for i = 1:k
    K = size(U{i},2);
    norms = max(1e-15,sqrt(sum(U{i}.^2,1)))';
    U{i} = U{i}*spdiags(norms.^-1,0,K,K);
    end
    
    
    function [obj, dT] = CalculateObj(T, U, J)
    mn = numel(U);
    One = eye(J);
    Jsize = [J J J];
    Core = reshape(One*transpose(kr(One,One)),Jsize);
    Core = tensor(Core);
    UCore = TensorChainProduct(Core, U, [1:mn]);
    dT = T - UCore;
    obj = norm(dT);
    
