
clear all
clc

addpath( genpath(pwd) );

Dataset_name = {'new_COIL20'};
%Dataset_name = {'new_COIL20','new_ORL','new_PIEP3I3_32x32','new_UMIST'};
%=============================================

for iDB = 1:length( Dataset_name )% DB is data base; and length(DB) is number of Data Base.
    
    % load data
    name = Dataset_name{ iDB };
    fprintf('Dataset Name:   %s\n', name);
    fprintf('Loading   ...');
    load( name );% loading dataset
    %sn = 20; % signal to noise ratio
    % -- add noise --
    %Noise = max(0, randn(size(fea)));
    %Noise = tensor(abs(rand(Nway)));
    %Noise = 10^(-sn/20)*norm(fea)/norm(Noise)*Noise;
    %fea = fea + Noise; % M is an N-way tensor
    fprintf('Done\n');
    nclass = length(find(gnd==1));
    % =====================================================================
    options = [];
    options.maxIter = 10;
    options.error = 1e-5;
    options.nRepeat = 50;
    type_method = 'HyperNTF'; % as type = 'NTD_LE' & options.alpha = 0, that is NTD algorithm
    tensor_shape    = [32 32];% the dimension for dataset dependent reshaped tensors
    J = 8;
    
    % =====================================================================
    runtimes = 10; % runing 10 times
    cross_num = 10;
    % =====================================================================
    for rn = 1 : runtimes
        options.alpha = 0; % for NTD_LE
        options.K = 3;
        %indx = zeros(nclass, 10*rn);
        %for n = 1:10*rn
        %    indx(:,n) = find(gnd==n);
        %end
        % =================================================================
        indx = zeros(nclass*2*rn, 1);
        n = 2*rn +1;
        indx(:,1) = find(gnd<n);
        indx = indx(:);
        X = fea(indx,:);
        Y = gnd(indx,1);
        t1 = clock;% count time
        for cros = 1 : cross_num
            % =============================================================
            train = X';                         %===================%
            train_label = Y;                     %      ѡ��ѵ����    %
            nsamples = size(X,1);
            nClasses = length(unique(Y));
            Xsize = [tensor_shape, nsamples];
            % =============================================================
            [U, ~, info, ela] = HyperNTF(train, Xsize, J, options);
            %[U, Core, J, ~, info, ela] = NTD_hypergraph(train, tensor_shape, options);
            %[U, Core, J, ~, info, ela] = NTD_LLE(train, tensor_shape, options);
            %[U, Core, J, ~, info, ela] = NTD_LE(train, tensor_shape, options);
            %[U, Core, J, nIter_final, infoo, ela] = NPNMF(train, tensor_shape, options);
            %[U, Core, J, nIter_final, infoo, ela] = NPNMF_LE(train, tensor_shape, options);
            %[U, Core, J, nIter_final, infoo, ela] = NPNMF_LTSA(train, tensor_shape, options);
            %[U, Core, J, info, ela] = NTD(train, tensor_shape, options);
            %[U, Core, J, info, ela] = Tri_ONTD(train, tensor_shape, options);
            % ============================== LE ===========================
            V = U{end};
            label = litekmeans(V, nClasses,'Replicates', 20);
            label = bestMap(train_label, label);
            results.AC(rn,cros) = length(find(train_label == label))/length(train_label);
            results.NMI(rn,cros) = MutualInfo(train_label,label);
            iinf = cros + (rn - 1)*cross_num;
            results.rse{iinf} = ela;
            %clear V label;
        end
        %results.runingtime{rn} = etime(clock,t1)/cross_num;
        %P = tsne(V');
        %gscatter(P(:,1),P(:,2),label);
        results.J = J;
    end
    results.method = 'HRNTF';
    save(['Results\', 'res_', 'HRNTF', name ],  'results');
    clear results;
end


