function Y = etth(U, n, J)
N = numel(U);
list = [1:n-1 n+1:N];
Y = ones(J);
for i=1:numel(list)
    V = U{i}'*U{i};
    Y = Y.*V;
end
    
end