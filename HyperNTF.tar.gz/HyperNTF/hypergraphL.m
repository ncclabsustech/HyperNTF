function [ plus_L, minus_L ] = hypergraphL(X, k)
% X: each column denotes a data point
% K: the k value of K_NN
% d: the dimensionality reduction
%
% Y: each column denotes a data point.
paramnn.k = k;
[Nf, N] = size(X);
[indx, indy, d] = gsp_nn_distanz(X, X, paramnn);
sigma = mean(d)^2;
wt = exp(-d.^2/sigma);
E = cell(N,1);
w = zeros(N,1);
for ii = 1:N
    edge = indx((1:k)+(ii-1)*k);
    E{ii} = edge;
    w(ii) = sum(wt(edge));
end
%G = gsp_hypergraph(N,E,'normalized', w);
Ne = numel(E);
W = sparse(N,Ne);
for ii = 1:Ne
% Here we use W for HW...
  W(E{ii},ii) = sqrt(w(ii));
end
de = sum(W >0,1)';
dv = sum(W.^2,2);
dve = sum(W*de,2);
% I - D^{-1/2}*H*W*De^*D^{-1/2}  
A = W*W' - diag(dv);
D = diag(dv.^(-0.5)) * W * diag(de.^(-1)) * W' *diag(dv.^(-0.5));
minus_L = diag(dv.^(0.5)) * D *diag(dv.^(0.5));
minus_L = full(minus_L);
plus_L = full(diag(dv));
I = eye(N);
M = I - D;
L = sqrt(M.*M);
%plus_L = (L + M)./2;
%minus_L = (L - M)./2;

end


